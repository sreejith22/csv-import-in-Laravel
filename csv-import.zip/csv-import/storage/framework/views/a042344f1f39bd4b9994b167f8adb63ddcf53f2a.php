<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /var/www/html/redmine/public/csv-import/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>