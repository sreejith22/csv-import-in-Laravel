<?php echo e($slot); ?>

<?php /**PATH /var/www/html/redmine/public/csv-import/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>