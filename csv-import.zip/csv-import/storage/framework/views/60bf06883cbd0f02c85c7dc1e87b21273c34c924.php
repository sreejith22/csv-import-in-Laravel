<!DOCTYPE html>
<html>
<head>
 <title>CSV IMPORT</title>
</head>
<body>

 <p><?php echo e($maildata); ?></p>
 
</body>
</html> <?php /**PATH /var/www/html/redmine/public/csv-import/resources/views/emails/demoMail.blade.php ENDPATH**/ ?>