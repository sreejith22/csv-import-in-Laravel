<!DOCTYPE html>
<html>
<head>
 <title>CSV IMPORT</title>
</head>
<body>

 <p>{{ $maildata }}</p>
 
</body>
</html> 